# quickLines
A simple package that will extract emission line profile information given a 1D spectra of a galaxy
